# 🕶️ База Знаний: Свободный Интернет

Добро пожаловать в репозиторий с инструкциями по настройке VPN-серверов и инструментов для обхода блокировок. Здесь собраны лучшие практики и проверенные скрипты.

## 🛠 Инструкции по установке

1.  **[Установка 3X-UI-pro with REALITY](manuals/3x-ui-pro-reality.md)**
    *   Панель управления и инбаунды на 443 порту.
2.  **[Установка 3x-ui с 4 инбаундами](manuals/3x-ui-4-inbounds.md)**
    *   Свежий скрипт для расширенной настройки.
3.  **[Установка Hysteria2 (Blitz)](manuals/hysteria2-blitz.md)**
    *   Скоростной протокол на базе UDP — отличная альтернатива VLESS.
4.  **[Каскадный VPN (Chain: Client -> Russia -> World)](manuals/cascading-vpn.md)**
    *   Настройка цепочки серверов для максимальной маскировки.
5.  **[Установка xkeen](manuals/xkeen-keenetic.md)**
    *   Интеграция Xray напрямую в роутеры Keenetic.

## 🔗 Полезные ресурсы

*   **[Генератор конфигураций](https://rockblack.info/mihomo_generator)** — удобный тул для Xray и Mihomo.
*   **[Rockblack IP для AmneziaWG](https://github.com/RockBlack-VPN/ip-address)** — актуальные адреса для настройки.

---
*Материалы подготовлены для канала [«Двое в каноэ»](https://t.me/max_dmitrov).*
🕶️ **Stay secure.**
